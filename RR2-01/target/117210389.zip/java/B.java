
public interface B<T> extends A<T> {
	
	public void m(String s);
	
}
