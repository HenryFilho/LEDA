import java.util.Collection;

public class C<T> implements A<T> {

	@Override
	public void m(T t) {
		// TODO Auto-generated method stub
		
	}

	public void m(Collection<?> obj) {
		//sfdasdfggwegsfehtjryjy
	}
	
}
