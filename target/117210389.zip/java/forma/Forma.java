package forma;

public interface Forma {

	public abstract double calcArea();

}
